﻿using System;
using System.Collections.Generic;
using System.Net;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Task.Configuration;
using Task.Data;


namespace Task
{
    [TestClass]
    public class ApiTests : WebApiTestConfig
    {
        #region -- GET --

        [TestMethod]
        public void ApiGetAllCompanies()
        {
            var response = SendGetRequest("companies");

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var result = ReadResult<IEnumerable<Data.Company>>(response);
           
            result.Should().NotBeEmpty();
        }

        [TestMethod]
        public void ApiGetCompanyById()
        {
            int companyId = ApiCreateCompany();

            var response = SendGetRequest("companies/id/" + companyId);

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var result = ReadResult<Data.CompanyName>(response);
            result.Name.Should().NotBeEmpty();
        }


        [TestMethod]
        public void ApiGetAllEmployees()
        {
            var response = SendGetRequest("employees");

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var result = ReadResult<IEnumerable<Data.Employee>>(response);

            result.Should().NotBeEmpty();
        }

        [TestMethod]
        public void ApiGetEmployeeById()
        {
            int employeeId = ApiCreateEmployee();

            var response = SendGetRequest("employees/id/" + employeeId);

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var result = ReadResult<Data.EmployeeName>(response);

            result.Name.Should().NotBeEmpty();
        }


        #endregion



        #region -- POST --
        [TestMethod]
        public static int ApiCreateCompany()
        {
            var data = new CompanyName
            {
                Name = "TestCompany" + DateTime.Now
            };

            var response = SendPostRequest("companies", data);

            response.StatusCode.Should().Be(HttpStatusCode.Created);

            var result = ReadResult<int>(response);

            result.Should().BeGreaterThan(0);

            return result;
        }

        [TestMethod]
        public static int ApiCreateEmployee()
        {
            var data = new EmployeeName
            {
                Name = "TestEmployee" + DateTime.Now
            };

            var response = SendPostRequest("employees", data);

            response.StatusCode.Should().Be(HttpStatusCode.Created);

            var result = ReadResult<int>(response);

            result.Should().BeGreaterThan(0);

            return result;
        }

        #endregion

        #region -- DELETE --
        [TestMethod]
        public void ApiDeleteCompany()
        {
            int companyId = ApiCreateCompany();

            var response = DeleteRequest("companies/id/" + companyId);
            response.StatusCode.Should().Be(HttpStatusCode.OK);
           
            var result = ReadResult<string>(response);
            result.Should().Contain("Success");
        }

        [TestMethod]
        public void ApiDeleteEmployee()
        {
            int employeeId = ApiCreateEmployee();
           
            var response = DeleteRequest("employees/id/" + employeeId);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
           
            var result = ReadResult<string>(response);

            result.Should().Contain("Success");
        }

        #endregion
        }

}
