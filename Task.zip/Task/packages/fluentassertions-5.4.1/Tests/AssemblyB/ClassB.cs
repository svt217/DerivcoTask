﻿
namespace AssemblyB
{
    public class ClassB
    {
    }
}
