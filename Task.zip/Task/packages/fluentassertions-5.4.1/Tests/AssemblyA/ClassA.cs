﻿
using AssemblyB;

namespace AssemblyA
{
    public class ClassA
    {
        public void DoSomething()
        {
            var classB = new ClassB();
        }
    }
}
