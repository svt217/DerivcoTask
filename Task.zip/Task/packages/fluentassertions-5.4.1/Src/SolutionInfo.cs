using System.Reflection;

[assembly: AssemblyCompany("www.continuousimprover.com")]
[assembly: AssemblyCopyright("Copyright Dennis Doomen 2010-2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]