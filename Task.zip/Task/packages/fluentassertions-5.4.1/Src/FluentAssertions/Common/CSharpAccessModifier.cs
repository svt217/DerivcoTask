﻿namespace FluentAssertions.Common
{
    public enum CSharpAccessModifier
    {
        Public,
        Private,
        Protected,
        Internal,
        ProtectedInternal,
        InvalidForCSharp
    }
}
