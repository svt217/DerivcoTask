﻿namespace FluentAssertions.Common
{
    public interface IConfigurationStore
    {
        string GetSetting(string name);
    }
}
