namespace FluentAssertions.Equivalency
{
    public enum EnumEquivalencyHandling
    {
        ByValue,
        ByName
    }
}
