namespace FluentAssertions.Equivalency
{
    public enum OrderStrictness
    {
        Strict,
        NotStrict,
        Irrelevant
    }
}
