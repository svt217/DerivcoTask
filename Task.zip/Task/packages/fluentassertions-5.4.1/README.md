[![Build status](https://ci.appveyor.com/api/projects/status/h60mq3e5uf5tuout/branch/master?svg=true)](https://ci.appveyor.com/project/dennisdoomen/fluentassertions/branch/master) [![NuGet](https://img.shields.io/nuget/vpre/FluentAssertions.svg)](https://www.nuget.org/packages/FluentAssertions)

# What is this and why do I need this?
See http://fluentassertions.com for background information, usage documentation, an extensibility guide, support information and more tips & tricks.

# How do I build this?
Install Visual Studio 2017 or JetBrains Rider 2017.1 and Build Tools 2017 and run

`build.ps1`


