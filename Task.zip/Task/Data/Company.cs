﻿using System;
namespace Task.Data
{
    abstract class Company
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
