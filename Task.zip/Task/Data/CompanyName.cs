﻿using System;
namespace Task.Data
{
    internal class CompanyName 
    {
        public string Name { get; set; }
    }
}
