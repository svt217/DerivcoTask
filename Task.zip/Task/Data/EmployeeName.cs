﻿using System;
namespace Task.Data
{
    internal class EmployeeName
    {
        public string Name { get; set; }
    }
}
