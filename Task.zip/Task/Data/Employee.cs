﻿using System;
namespace Task.Data
{
    internal class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
