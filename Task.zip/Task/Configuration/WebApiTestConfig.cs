﻿using System;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;


namespace Task.Configuration
{
    public class WebApiTestConfig
    {
        const string UserName = "testName";
        const string Password = "test";
        protected static string location = "https://mobilewebserver9-pokertest8ext.installprogram.eu/TestApi";
        protected static string baseUrl = location + "/api/automation/";
        protected static string grant_type = "password";

        protected static HttpResponseMessage SendPostRequest<T>(string url, T data)
        {
            HttpResponseMessage response;
            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(180);
                AuthorizationAndSetupClient(client);
                response = client.PostAsJsonAsync(url, data).Result;
            }
            return response;
        }


        protected static HttpResponseMessage SendGetRequest(string uri)
        {
            HttpResponseMessage response;
            using (var client = new HttpClient())
            {
                AuthorizationAndSetupClient(client);
                var message = new HttpRequestMessage(HttpMethod.Get, uri);
                response = client.SendAsync(message).Result;
            }
            return response;
        }

        protected static HttpResponseMessage DeleteRequest(string url)
        {
            HttpResponseMessage response;
            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(180);
                AuthorizationAndSetupClient(client);
                response = client.DeleteAsync(url).Result;
                if (response.IsSuccessStatusCode)
                {
                    String.Format("Success!Object was deleted, response={0}",response);
                }
                else
                    String.Format("Error! Object is still exists, response={0}", response);
            }
            return response;
        }


        protected static T ReadResult<T>(HttpResponseMessage response)
        {
            return response.Content.ReadAsAsync<T>().Result;
        }


        private static async Task<string> GetAPIToken(string userName, string password, string apiBaseUrl)
        {
            using (var client = new HttpClient())
            {
                //setup client:
                SetupClient(client);

                //setup login data:
                var formContent = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("username", userName),
                    new KeyValuePair<string, string>("password", password),
                    new KeyValuePair<string, string>("grant_type", grant_type)
                });

                //send request
                HttpResponseMessage responseMessage = await client.PostAsync("/token", formContent);

                //get access token from response body
                var responseJson = await responseMessage.Content.ReadAsStringAsync();
                var jObject = JObject.Parse(responseJson);
                return jObject.GetValue("access_token").ToString();
            }
        }


        protected static void SetupClient(HttpClient client)
        {
            //setup client:
            client.BaseAddress = new Uri(baseUrl);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        }


        protected static void AuthorizationAndSetupClient(HttpClient client)
        {
            //get token:
            var token = GetAPIToken(UserName, Password, baseUrl).Result;
            String.Format("Token: {0}", token);

            SetupClient(client);
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        }

    }
}
